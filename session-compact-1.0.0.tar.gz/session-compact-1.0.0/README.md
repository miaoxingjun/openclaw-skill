# 🗜️ Session Compact Skill

> 智能会话压缩工具 - 基于 Claude Code 的 Session Memory Compact 机制

## 简介

Session Compact 是一套完整的会话压缩和记忆管理系统，帮助你自动归档长对话、生成结构化摘要、节省 tokens。

**核心特性**:
- ✅ 自动归档长对话（50k tokens 阈值）
- ✅ 生成结构化摘要（关键决策、错误修复）
- ✅ 节省 90-98% tokens
- ✅ 零成本运行（不调用 LLM）
- ✅ 持久化记忆到 session-memory.md

## 安装

```bash
openclaw skills install session-compact
```

## 快速开始

```bash
# 手动压缩
/compact

# 检查会话状态
python3 ~/.openclaw/workspace/compact-monitor.py --check
```

## 文档

详细文档请查看: [SKILL.md](SKILL.md)

## 文件结构

```
session-compact-1.0.0/
├── SKILL.md                 # Skill 主文档
├── README.md                # 本文件
├── scripts/
│   ├── compact-trigger.py   # 手动压缩脚本
│   ├── micro-compact.py     # 微压缩脚本
│   └── compact-monitor.py   # 自动监控脚本
├── docs/
│   └── IMPLEMENTATION.md    # 技术实现文档
└── references/
    └── claude-code-learnings.md  # Claude Code 学习笔记
```

## 许可证

MIT

## 作者

黑米 (zhangxuzhao)
