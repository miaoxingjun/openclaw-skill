---
name: session-compact
description: "智能会话压缩工具 - 自动归档长对话、生成摘要、节省 tokens"
metadata:
  session-compact:
    emoji: "🗜️"
    version: "1.0.0"
    author: "黑米 (zhangxuzhao)"
    license: "MIT"
    tags: ["productivity", "session-management", "token-saving", "memory"]
    repository: "https://github.com/zhangxuzhao/openclaw-skills"
---

# 🗜️ Session Compact Skill

> 智能会话压缩工具 - 基于 Claude Code 的 Session Memory Compact 机制

## 📋 概述

**Session Compact** 是一套完整的会话压缩和记忆管理系统，帮助你：

- ✅ **自动归档长对话** - 超过阈值自动压缩
- ✅ **生成结构化摘要** - 提取关键决策、错误修复
- ✅ **节省 tokens** - 减少 90%+ 的上下文开销
- ✅ **持久化记忆** - 将重要信息写入 `session-memory.md`
- ✅ **零成本运行** - 不调用 LLM，纯规则引擎

## 🎯 适用场景

当你遇到以下情况时使用：

1. **对话太长** - 会话超过 50k tokens，响应变慢
2. **需要回顾** - 想快速了解之前的关键决策
3. **节省成本** - 减少后续对话的 token 消耗
4. **知识沉淀** - 将对话精华归档为长期记忆

## 🚀 快速开始

### 1. 安装 Skill

```bash
# 从市场安装
openclaw skills install session-compact

# 或手动安装
cd ~/.openclaw/skills/session-compact-1.0.0
cp scripts/* ~/.openclaw/workspace/
```

### 2. 配置 OpenClaw

确保 `~/.openclaw/openclaw.json` 中启用了 compact hook：

```json
{
  "hooks": {
    "compact": {
      "enabled": true
    }
  }
}
```

### 3. 手动触发压缩

```bash
# 方式 1: 使用命令
/compact

# 方式 2: 自然语言
"黑米，压缩当前会话"
"帮我压缩一下对话"

# 方式 3: 运行脚本
python3 ~/.openclaw/workspace/compact-trigger.py
```

### 4. 自动压缩（推荐）

配置自动监控（每小时检查一次）：

```bash
# 编辑 crontab
crontab -e

# 添加以下内容（每小时检查）
0 * * * * python3 ~/.openclaw/workspace/compact-monitor.py --check
```

## 🛠️ 核心功能

### 功能 1: Session Memory Compact

**作用**: 归档长会话，生成结构化摘要

**触发条件**:
- 手动: `/compact` 命令
- 自动: 会话 tokens ≥ 50,000

**输出**:
1. **归档文件**: `~/.openclaw/workspace/archived-sessions/{session-id}.jsonl`
2. **摘要文件**: `~/.openclaw/workspace/memory/{date}-compact.md`
3. **记忆更新**: `~/.openclaw/workspace/session-memory.md`

**示例**:
```
主人：/compact

黑米：✅ 会话压缩完成！
   - 归档: archived-sessions/27bf67bd-....jsonl
   - 摘要: memory/2026-04-05-compact.md
   - Token 节省: 98.1% (53k → 1k)
```

### 功能 2: Micro Compact（微压缩）

**作用**: 清理旧工具结果，节省少量 tokens

**触发条件**:
- 30 分钟无交互后自动触发
- 保留最近 2 个工具结果

**效果**:
- 节省 ~784 tokens/次
- 无需 LLM 调用
- 100ms 内完成

### 功能 3: Auto Compact Monitor

**作用**: 定期监控会话长度，自动触发压缩

**运行方式**:
```bash
# 手动检查
python3 ~/.openclaw/workspace/compact-monitor.py --check

# 自动压缩指定会话
python3 ~/.openclaw/workspace/compact-monitor.py --compact SESSION_KEY
```

## 📊 性能指标

| 指标 | 数值 |
|------|------|
| **压缩率** | 90-98% |
| **速度** | 100ms (Micro) / 1-3s (Full) |
| **成本** | $0 (不调用 LLM) |
| **Token 节省** | 50k → 1-5k |
| **自动触发阈值** | 50,000 tokens |

## 🔧 配置选项

编辑 `~/.openclaw/workspace/compact-monitor.py` 中的 `DEFAULT_CONFIG`：

```python
DEFAULT_CONFIG = {
    'compact_threshold': 50000,  # 自动触发阈值 (tokens)
    'min_tokens': 8000,          # 最少保留 tokens
    'max_tokens': 35000,         # 最多保留 tokens
    'gap_threshold_minutes': 30, # Micro Compact 时间阈值
    'keep_recent': 2,            # 保留最近 N 个工具结果
    'log_file': Path.home() / '.openclaw' / 'workspace' / 'compact-monitor.log',
}
```

## 📁 文件结构

```
~/.openclaw/workspace/
├── compact-trigger.py          # 手动压缩脚本
├── micro-compact.py            # 微压缩脚本
├── compact-monitor.py          # 自动监控脚本
├── session-memory.md           # 对话摘要（持久化）
├── archived-sessions/          # 归档的会话文件
│   └── {session-id}.jsonl
└── memory/
    └── {date}-compact.md       # 每日压缩摘要
```

## 🧪 测试

### 测试手动压缩

```bash
# 1. 查看当前会话状态
openclaw session status

# 2. 手动触发
/compact

# 3. 检查输出
cat ~/.openclaw/workspace/session-memory.md
ls -lh ~/.openclaw/workspace/archived-sessions/
```

### 测试 Micro Compact

```bash
# 运行微压缩
python3 ~/.openclaw/workspace/micro-compact.py

# 预期输出:
# ✅ Micro Compact 完成
#    - 清理: 2 个旧工具结果
#    - 节省: ~784 tokens
```

### 检查自动监控

```bash
# 手动运行检查
python3 ~/.openclaw/workspace/compact-monitor.py --check

# 预期输出:
# 📊 会话监控检查
#    - 当前会话: 27bf67bd-...
#    - Token 数: 15,234 / 50,000
#    - 状态: ✅ 无需压缩
```

## ⚠️ 注意事项

1. **备份优先**: 压缩前会自动备份，如需恢复可查看 `archived-sessions/`
2. **不可逆操作**: 归档后无法恢复原会话，但摘要已保存
3. **长时记忆**: 重要决策会自动写入 `session-memory.md`
4. **性能影响**: Micro Compact 几乎无影响，Full Compact 需 1-3 秒

## 🔍 故障排查

### Q1: `/compact` 命令无响应？
**A**: 检查 hook 是否注册：
```bash
openclaw hooks list | grep compact
```

### Q2: `session-memory.md` 未更新？
**A**: 确保会话达到 50k tokens 或手动触发

### Q3: 压缩后丢失信息？
**A**: 查看归档文件：
```bash
cat ~/.openclaw/workspace/archived-sessions/{session-id}.jsonl
```

### Q4: 自动监控未运行？
**A**: 检查 cron 任务：
```bash
crontab -l | grep compact
```

## 📖 进阶使用

### 自定义摘要提取规则

编辑 `~/.openclaw/workspace/compact-trigger.py` 中的关键词词典：

```python
DECISION_KEYWORDS = ["决定", "选择", "方案", "采用", "修改"]
ERROR_KEYWORDS = ["错误", "失败", "修复", "解决", "bug"]
COMPLETION_KEYWORDS = ["完成", "实现", "创建", "添加", "更新"]
```

### 集成到 CI/CD

```bash
# 在 CI 脚本中添加
python3 ~/.openclaw/workspace/compact-monitor.py --check
if [ $? -eq 0 ]; then
    echo "✅ Session compact successful"
fi
```

### 批量压缩历史会话

```bash
# 查找所有会话
for session in ~/.openclaw/agents/main/sessions/*.jsonl; do
    session_key=$(basename $session .jsonl)
    python3 ~/.openclaw/workspace/compact-monitor.py --compact $session_key
done
```

## 🔄 更新日志

### v1.0.0 (2026-04-05)
- ✅ 初始版本
- ✅ Session Memory Compact
- ✅ Micro Compact
- ✅ Auto Compact Monitor
- ✅ 自动摘要提取到 session-memory.md
- ✅ 支持手动 `/compact` 命令

## 🤝 贡献

欢迎提交 Issue 和 PR！

**作者**: 黑米 (zhangxuzhao)  
**许可证**: MIT  
**仓库**: https://github.com/zhangxuzhao/openclaw-skills

---

🌾 **让黑米帮你节省 tokens，保持对话清爽！**
