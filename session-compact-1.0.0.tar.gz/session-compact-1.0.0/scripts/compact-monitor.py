#!/usr/bin/env python3
"""
compact-monitor.py - 定期监控对话长度并触发 compact

用法：
  python3 compact-monitor.py [--check] [--compact SESSION_KEY]

功能：
  1. 定期检查所有活跃会话的 token 数量
  2. 如果超过阈值，自动触发 compact
  3. 发送通知到飞书

配置：
  编辑脚本开头的 CONFIG
"""

import json
import os
import sys
import glob
from pathlib import Path
from datetime import datetime

# ============ 配置 ============
CONFIG = {
    'workspace_dir': Path.home() / '.openclaw' / 'workspace',
    'sessions_dir': Path.home() / '.openclaw' / 'agents' / 'main' / 'sessions',
    'session_memory_file': Path.home() / '.openclaw' / 'workspace' / 'session-memory.md',
    'compact_threshold': 50000,  # token 阈值
    'log_file': Path.home() / '.openclaw' / 'workspace' / 'compact-monitor.log',
}

# 飞书配置（用于发送通知）
FEISHU_CONFIG = {
    'app_id': 'cli_a94e040c4f389bc9',
    'app_secret': 'GI1ZvRxRRMp9AII2Vbtu5gydam3tpbQg',
    'chat_id': 'oc_53d6dd75531cac5fb923c4bb664b8926',
    'user_id': 'ou_b95acecc371f97d06a84719ba5d0633d',
}

# ============ 工具函数 ============

def log(message: str):
    """记录日志"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_line = f"[{timestamp}] {message}\n"
    print(log_line.strip())
    
    CONFIG['log_file'].parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG['log_file'], 'a', encoding='utf-8') as f:
        f.write(log_line)

def estimate_tokens(text: str) -> int:
    """粗略估算 token 数"""
    if not text:
        return 0
    # 1 token ≈ 2.5 chars（中英文混合）
    return len(text) // 2.5

def get_all_sessions():
    """获取所有会话（sessions.json + JSONL 文件）"""
    sessions_dir = CONFIG['sessions_dir']
    
    # 1. 从 sessions.json 获取会话元信息
    sessions_file = sessions_dir / 'sessions.json'
    sessions_meta = {}
    if sessions_file.exists():
        try:
            with open(sessions_file, 'r', encoding='utf-8') as f:
                sessions_meta = json.load(f)
        except Exception as e:
            log(f"❌ 读取 sessions.json 失败: {e}")
    
    # 2. 扫描所有 JSONL 文件
    jsonl_files = list(sessions_dir.glob('*.jsonl'))
    
    result = {}
    for jsonl_file in jsonl_files:
        session_id = jsonl_file.stem  # 文件名去掉 .jsonl
        
        # 统计消息数
        try:
            message_count = 0
            total_chars = 0
            with open(jsonl_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if '"type":"message"' in line:
                        message_count += 1
                        # 粗略统计字符数
                        total_chars += len(line)
            
            result[session_id] = {
                'session_file': str(jsonl_file),
                'message_count': message_count,
                'total_chars': total_chars,
                'meta': sessions_meta.get(session_id, {}),
            }
        except Exception as e:
            log(f"❌ 读取 {jsonl_file.name} 失败: {e}")
    
    return result

def calculate_session_tokens(session_data: dict) -> int:
    """计算会话的总 token 数"""
    messages = session_data.get('messages', [])
    total_tokens = 0
    
    for msg in messages:
        msg_type = msg.get('type', '')
        if msg_type == 'user':
            content = msg.get('message', {}).get('content', '')
            if isinstance(content, str):
                total_tokens += estimate_tokens(content)
            elif isinstance(content, list):
                for block in content:
                    if block.get('type') == 'text':
                        total_tokens += estimate_tokens(block.get('text', ''))
                    elif block.get('type') == 'tool_result':
                        total_tokens += estimate_tokens(str(block.get('content', '')))
        
        elif msg_type == 'assistant':
            content = msg.get('message', {}).get('content', [])
            if isinstance(content, list):
                for block in content:
                    if block.get('type') == 'text':
                        total_tokens += estimate_tokens(block.get('text', ''))
                    elif block.get('type') == 'tool_use':
                        total_tokens += estimate_tokens(
                            block.get('name', '') + 
                            json.dumps(block.get('input', {}))
                        )
    
    return int(total_tokens)

def check_sessions():
    """检查所有会话的 token 使用情况"""
    log("🔍 开始检查会话...")
    
    sessions = get_all_sessions()
    if not sessions:
        log("⚠️  未找到任何会话")
        return
    
    alerts = []
    
    for session_id, session_info in sorted(sessions.items(), key=lambda x: x[1]['total_chars'], reverse=True):
        # 估算 token（1 token ≈ 2.5 chars）
        estimated_tokens = int(session_info['total_chars'] / 2.5)
        message_count = session_info['message_count']
        
        log(f"  📝 {session_id[:40]}...")
        log(f"     消息数: {message_count}, 字符数: {session_info['total_chars']:,}, 估算 token: ~{estimated_tokens:,}")
        
        if estimated_tokens > CONFIG['compact_threshold']:
            alerts.append({
                'session_id': session_id,
                'tokens': estimated_tokens,
                'messages': message_count,
                'file': session_info['session_file'],
            })
            log(f"     ⚠️  超过阈值！建议 compact")
    
    log("")
    if alerts:
        log(f"⚠️  发现 {len(alerts)} 个会话需要 compact")
        send_alert(alerts)
    else:
        log("✅ 所有会话正常")

def send_alert(alerts: list):
    """发送飞书通知"""
    try:
        import requests
        
        # 获取 token
        token_resp = requests.post(
            "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
            json={
                "app_id": FEISHU_CONFIG['app_id'],
                "app_secret": FEISHU_CONFIG['app_secret']
            }
        )
        tenant_token = token_resp.json().get('tenant_access_token')
        
        if not tenant_token:
            log("❌ 获取飞书 token 失败")
            return
        
        headers = {
            "Authorization": f"Bearer {tenant_token}",
            "Content-Type": "application/json"
        }
        
        # 构建消息
        message_lines = ["🌾 Compact 监控提醒\n"]
        message_lines.append(f"发现 {len(alerts)} 个会话 token 超限：\n")
        
        for alert in alerts[:5]:  # 最多显示 5 个
            message_lines.append(
                f"• {alert['session_id'][:50]}...\n"
                f"  - 消息数: {alert['messages']}\n"
                f"  - Token 数: ~{alert['tokens']:,}\n"
            )
        
        message_lines.append("\n💡 建议：执行 /compact 命令或等待自动 compact")
        
        message_text = ''.join(message_lines)
        
        # 发送到个人
        params = {"receive_id_type": "open_id"}
        payload = {
            "receive_id": FEISHU_CONFIG['user_id'],
            "msg_type": "text",
            "content": json.dumps({"text": message_text}, ensure_ascii=False)
        }
        
        resp = requests.post(
            "https://open.feishu.cn/open-apis/im/v1/messages",
            headers=headers,
            params=params,
            json=payload
        )
        
        if resp.json().get('code') == 0:
            log("✅ 飞书通知已发送")
        else:
            log(f"❌ 飞书通知发送失败: {resp.json()}")
    
    except ImportError:
        log("⚠️  requests 库未安装，跳过通知")
    except Exception as e:
        log(f"❌ 发送通知失败: {e}")

def auto_compact_session(session_key: str):
    """自动触发 compact（简化版本）"""
    log(f"🔄 开始自动 compact: {session_key}")
    
    # 1. 读取 session memory
    sm_file = CONFIG['session_memory_file']
    if sm_file.exists():
        session_memory = sm_file.read_text(encoding='utf-8')
        log(f"✅ 读取到 session memory: {len(session_memory)} 字符")
    else:
        log("⚠️  session memory 不存在，请先更新摘要")
        return
    
    # 2. 提示用户
    log(f"💡 Session memory 已准备好，下次对话时将自动使用")
    log(f"   文件: {sm_file}")

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Compact 监控工具')
    parser.add_argument('--check', action='store_true', help='检查所有会话')
    parser.add_argument('--compact', metavar='SESSION_KEY', help='手动触发 compact')
    args = parser.parse_args()
    
    if args.check:
        check_sessions()
    elif args.compact:
        auto_compact_session(args.compact)
    else:
        # 默认行为：检查
        check_sessions()

if __name__ == '__main__':
    main()
