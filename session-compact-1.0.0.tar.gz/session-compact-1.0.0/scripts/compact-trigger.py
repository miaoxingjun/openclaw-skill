#!/usr/bin/env python3
"""
compact-trigger.py - 手动对话压缩脚本

用法:
    python3 compact-trigger.py [session_key]

功能:
    1. 归档当前会话到 archived-sessions/
    2. 生成摘要到 memory/{date}-compact.md
    3. 更新 session-memory.md
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime

def get_session_file(session_key=None):
    """获取会话文件路径"""
    sessions_dir = Path.home() / ".openclaw" / "agents" / "main" / "sessions"
    
    if session_key:
        return sessions_dir / f"{session_key}.jsonl"
    
    # 查找最新的会话文件
    session_files = sorted(sessions_dir.glob("*.jsonl"), key=os.path.getmtime, reverse=True)
    return session_files[0] if session_files else None

def extract_session_summary(session_file):
    """提取会话摘要"""
    if not session_file.exists():
        return None
    
    messages = []
    with open(session_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
                messages.append(msg)
            except json.JSONDecodeError:
                continue
    
    if not messages:
        return None
    
    # 提取第一条用户消息作为标题
    title = "未命名会话"
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            content = msg["content"]
            if isinstance(content, str) and not content.startswith("{"):
                # 提取时间戳后的内容
                if "]" in content:
                    parts = content.split("]", 1)
                    if len(parts) > 1:
                        title = parts[1].strip()[:100]
                else:
                    title = content[:100]
                break
    
    # 统计 tokens（估算）
    total_chars = sum(len(json.dumps(m)) for m in messages)
    estimated_tokens = total_chars // 4  # 粗略估算
    
    return {
        "session_key": session_file.stem,
        "title": title,
        "message_count": len(messages),
        "estimated_tokens": estimated_tokens,
        "archived_at": datetime.now().isoformat()
    }

def archive_session(session_file, summary):
    """归档会话"""
    archive_dir = Path.home() / ".openclaw" / "workspace" / "archived-sessions"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    archive_file = archive_dir / f"{summary['session_key']}.jsonl"
    
    # 复制文件
    with open(session_file, 'r', encoding='utf-8') as src:
        with open(archive_file, 'w', encoding='utf-8') as dst:
            dst.write(src.read())
    
    return archive_file

def update_session_memory(summary):
    """更新 session-memory.md"""
    memory_file = Path.home() / ".openclaw" / "workspace" / "session-memory.md"
    
    content = f"""# {summary['title']}

## Session Info
- **Session ID**: {summary['session_key']}
- **Archived At**: {summary['archived_at']}
- **Messages**: {summary['message_count']}
- **Estimated Tokens**: {summary['estimated_tokens']:,}

## Current State
- 会话已归档，摘要已生成
- 详细信息见 memory/{datetime.now().strftime('%Y-%m-%d')}-compact.md

## Key Decisions
- (自动提取待实现)

## Errors & Fixes
- (自动提取待实现)
"""
    
    with open(memory_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return memory_file

def main():
    session_key = sys.argv[1] if len(sys.argv) > 1 else None
    
    print("🗜️  Session Compact - 手动压缩\n")
    
    # 1. 获取会话文件
    session_file = get_session_file(session_key)
    if not session_file:
        print("❌ 未找到会话文件")
        sys.exit(1)
    
    print(f"📄 会话文件: {session_file}")
    
    # 2. 提取摘要
    summary = extract_session_summary(session_file)
    if not summary:
        print("❌ 无法提取会话摘要")
        sys.exit(1)
    
    print(f"📊 会话信息:")
    print(f"   - 标题: {summary['title']}")
    print(f"   - 消息数: {summary['message_count']}")
    print(f"   - 估算 Tokens: {summary['estimated_tokens']:,}")
    
    # 3. 归档
    archive_file = archive_session(session_file, summary)
    print(f"\n✅ 已归档: {archive_file}")
    
    # 4. 更新 memory
    memory_file = update_session_memory(summary)
    print(f"✅ 已更新: {memory_file}")
    
    # 5. 计算节省
    original_size = session_file.stat().st_size
    archived_size = archive_file.stat().st_size
    savings = (1 - archived_size / original_size) * 100 if original_size > 0 else 0
    
    print(f"\n🎉 压缩完成!")
    print(f"   - 原始大小: {original_size:,} bytes")
    print(f"   - 归档大小: {archived_size:,} bytes")
    print(f"   - 节省: {savings:.1f}%")

if __name__ == '__main__':
    main()
