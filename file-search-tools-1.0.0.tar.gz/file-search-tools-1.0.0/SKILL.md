---
name: file-search-tools
description: "智能文件搜索工具 - GrepTool 内容搜索 + GlobTool 路径匹配，支持正则表达式和通配符"
metadata:
  file-search-tools:
    emoji: "🔍"
    version: "1.0.0"
    author: "黑米 (zhangxuzhao)"
    license: "MIT"
    tags: ["productivity", "file-search", "grep", "glob", "development"]
    repository: "https://github.com/zhangxuzhao/openclaw-skills"
---

# 🔍 File Search Tools Skill

> 智能文件搜索工具 - GrepTool + GlobTool，让文件搜索变得简单高效

## 📋 概述

**File Search Tools** 提供两个强大的文件搜索工具：

1. **GrepTool** - 文件内容搜索
   - ✅ 支持正则表达式
   - ✅ 显示上下文行
   - ✅ 多文件并行搜索
   - ✅ JSON 格式输出

2. **GlobTool** - 文件路径匹配
   - ✅ 支持通配符 `*`, `**`, `?`
   - ✅ 按文件类型过滤
   - ✅ 显示文件大小统计
   - ✅ 递归搜索支持

**核心优势**:
- 🚀 **速度快** - 基于系统命令，无需 LLM 调用
- 💰 **零成本** - $0 运行成本
- 🎯 **精准搜索** - 正则表达式 + 上下文
- 📊 **结构化输出** - 支持 JSON 格式，便于程序解析
- 🔒 **安全可靠** - 限制在工作区目录内

## 🎯 适用场景

### GrepTool 适用场景

1. **代码审查** - 查找特定函数、变量、类
2. **错误排查** - 搜索错误信息、日志关键词
3. **重构辅助** - 查找所有使用该函数的地方
4. **文档检索** - 搜索特定术语、配置项

### GlobTool 适用场景

1. **文件定位** - 查找特定类型的文件
2. **批量操作** - 先找文件，再批量处理
3. **项目分析** - 统计文件类型、大小
4. **路径探索** - 了解项目结构

## 🚀 快速开始

### 1. 安装 Skill

```bash
# 从市场安装
openclaw skills install file-search-tools

# 或手动安装
cd ~/.openclaw/skills/file-search-tools-1.0.0
cp scripts/* ~/.openclaw/workspace/
chmod +x ~/.openclaw/workspace/grep-tool.py
chmod +x ~/.openclaw/workspace/glob-tool.py
```

### 2. 基本用法

#### GrepTool - 搜索文件内容

```bash
# 基本搜索
python3 ~/.openclaw/workspace/grep-tool.py "pattern"

# 指定路径和文件类型
python3 ~/.openclaw/workspace/grep-tool.py "compact" \
  --path ~/.openclaw/workspace \
  --glob "*.py"

# 显示上下文
python3 ~/.openclaw/workspace/grep-tool.py "def main" \
  --context 5 \
  --max-results 10

# JSON 输出
python3 ~/.openclaw/workspace/grep-tool.py "error" \
  --glob "*.log" \
  --json
```

#### GlobTool - 查找文件

```bash
# 查找所有 Python 文件
python3 ~/.openclaw/workspace/glob-tool.py "*.py"

# 递归搜索
python3 ~/.openclaw/workspace/glob-tool.py "**/*.js" \
  --path ~/.openclaw/workspace

# 查找目录
python3 ~/.openclaw/workspace/glob-tool.py "*" \
  --type dir

# 显示统计信息
python3 ~/.openclaw/workspace/glob-tool.py "*.md" \
  --stats
```

## 🛠️ 核心功能

### GrepTool 功能详解

**命令格式**:
```bash
python3 grep-tool.py <pattern> [options]
```

**选项说明**:

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `pattern` | 搜索模式（支持正则） | 必需 |
| `--path PATH` | 搜索路径 | 当前目录 |
| `--glob GLOB` | 文件模式（如 `*.py`） | `*` |
| `--context N` | 上下文行数 | 2 |
| `--case-sensitive` | 区分大小写 | 否 |
| `--max-results N` | 最大结果数 | 50 |
| `--json` | 输出 JSON 格式 | 文本格式 |

**使用示例**:

```bash
# 1. 搜索所有包含 "session" 的 TypeScript 文件
python3 grep-tool.py "session" --glob "*.ts" --max-results 5

# 2. 搜索包含 "auto.*compact" 的 Python 文件（正则）
python3 grep-tool.py "auto.*compact" --glob "*.py" --case-sensitive

# 3. 搜索 handler.js 中的特定函数，显示 5 行上下文
python3 grep-tool.py "executeSessionMemoryCompact" \
  --glob "handler.js" \
  --context 5

# 4. JSON 输出（便于程序解析）
python3 grep-tool.py "def main" --glob "*.py" --json | jq '.[].file'
```

**输出格式**:

文本格式：
```
✅ 找到 5 个匹配项:

1. 📄 compact-monitor.py:3
   compact-monitor.py - 定期监控对话长度并触发 compact
   ... (2 行上文)
   ... (2 行下文)
```

JSON 格式：
```json
[
  {
    "file": "/path/to/file.py",
    "line": 3,
    "content": "compact-monitor.py - ...",
    "context": {
      "before": ["line 1", "line 2"],
      "after": ["line 4", "line 5"]
    }
  }
]
```

### GlobTool 功能详解

**命令格式**:
```bash
python3 glob-tool.py <pattern> [options]
```

**选项说明**:

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `pattern` | 文件模式（支持 `*`, `**`, `?`） | 必需 |
| `--path PATH` | 搜索路径 | 当前目录 |
| `--type TYPE` | 文件类型（`file`, `dir`, `all`） | `file` |
| `--max-results N` | 最大结果数 | 100 |
| `--json` | 输出 JSON 格式 | 文本格式 |
| `--stats` | 显示统计信息 | 否 |

**使用示例**:

```bash
# 1. 查找 workspace 中所有 Markdown 文件
python3 glob-tool.py "*.md" --path ~/.openclaw/workspace

# 2. 递归查找所有 TypeScript 文件
python3 glob-tool.py "**/*.ts" --max-results 20

# 3. 查找所有目录
python3 glob-tool.py "*" --type dir

# 4. JSON 输出 + 统计信息
python3 glob-tool.py "*.py" --json --stats

# 5. 查找以 "compact" 开头的 Python 文件
python3 glob-tool.py "compact*.py"
```

**输出格式**:

文本格式：
```
✅ 找到 7 个匹配项:

1. 📄 compact-monitor.py (8.9 KB)
2. 📄 compact-trigger.py (8.5 KB)
...

📊 统计:
   文件: 7
   目录: 0
   总大小: 52.8 KB
```

JSON 格式：
```json
[
  {
    "path": "/path/to/file.py",
    "relative_path": "file.py",
    "type": "file",
    "size": 4517,
    "size_human": "4.4 KB"
  }
]
```

## 🎓 实战案例

### 案例 1: 代码审查 - 查找所有使用某个函数的地方

```bash
# 查找所有调用 executeGrep 的地方
python3 grep-tool.py "executeGrep" --glob "*.ts" --context 2
```

### 案例 2: 错误排查 - 搜索日志中的错误

```bash
# 搜索最近一周的错误日志
python3 grep-tool.py "ERROR|Failed" --glob "*.log" --max-results 20
```

### 案例 3: 项目分析 - 统计文件大小

```bash
# 统计所有 Python 文件的大小
python3 glob-tool.py "**/*.py" --stats
```

### 案例 4: 批量操作 - 查找后处理

```bash
# 找到所有测试文件，然后运行测试
python3 glob-tool.py "test*.py" --json | jq -r '.[].path' | xargs -I {} python3 {}
```

### 案例 5: 重构辅助 - 查找旧 API 调用

```bash
# 搜索所有使用旧 API 的地方
python3 grep-tool.py "old_api_call" --glob "*.py" --json
```

## 📁 文件结构

```
file-search-tools-1.0.0/
├── SKILL.md                 # Skill 主文档
├── README.md                # 本文件
├── scripts/
│   ├── grep-tool.py         # GrepTool 核心脚本
│   └── glob-tool.py         # GlobTool 核心脚本
├── docs/
│   └── ADVANCED-USAGE.md    # 高级用法文档
└── references/
    └── claude-code-learnings.md  # Claude Code 学习笔记
```

## ⚙️ 高级配置

### 自定义默认参数

编辑脚本顶部的默认值：

**grep-tool.py**:
```python
parser.add_argument('--context', type=int, default=2, ...)
parser.add_argument('--max-results', type=int, default=50, ...)
```

**glob-tool.py**:
```python
parser.add_argument('--max-results', type=int, default=100, ...)
parser.add_argument('--type', choices=['file', 'dir', 'all'], default='file', ...)
```

### 集成到工作流

**Git Hook 示例**:
```bash
# .git/hooks/pre-commit
#!/bin/bash
# 检查是否包含调试代码
python3 ~/.openclaw/workspace/grep-tool.py "console.log|print\(.*debug" --glob "*.js" --glob "*.py"
if [ $? -eq 0 ]; then
    echo "❌ 发现调试代码，请移除后再提交"
    exit 1
fi
```

**CI/CD 集成**:
```yaml
# .github/workflows/test.yml
- name: Check for TODO comments
  run: |
    python3 ~/.openclaw/workspace/grep-tool.py "TODO|FIXME" --glob "*.py" --json > todo-report.json
```

## 🔍 故障排查

### Q1: 搜索结果为空？
**A**: 检查路径和文件模式是否正确：
```bash
# 先确认文件存在
python3 glob-tool.py "*.py" --path ~/.openclaw/workspace

# 再搜索内容
python3 grep-tool.py "pattern" --path ~/.openclaw/workspace --glob "*.py"
```

### Q2: 正则表达式不工作？
**A**: 确保使用正确的正则语法（Python 风格）：
```bash
# 正确：使用 .* 而非 *
python3 grep-tool.py "auto.*compact" --glob "*.py"

# 错误：* 是 glob 通配符，不是正则
python3 grep-tool.py "auto*compact" --glob "*.py"
```

### Q3: 搜索结果太多？
**A**: 使用 `--max-results` 限制：
```bash
python3 grep-tool.py "pattern" --max-results 10
```

### Q4: 想搜索特定编码的文件？
**A**: 当前脚本默认 UTF-8，如需支持其他编码，修改脚本：
```python
with open(filepath, 'r', encoding='gbk', errors='ignore') as f:
```

## 📊 性能对比

| 工具 | 速度 | 成本 | 灵活性 | 易用性 |
|------|------|------|--------|--------|
| **GrepTool** | ⚡⚡⚡ | $0 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **GlobTool** | ⚡⚡⚡ | $0 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| exec("grep") | ⚡⚡⚡ | $0 | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| LLM 搜索 | ⚡ | $0.5-2 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

## 🔄 更新日志

### v1.0.0 (2026-04-05)
- ✅ 初始版本
- ✅ GrepTool - 文件内容搜索
- ✅ GlobTool - 文件路径匹配
- ✅ 支持正则表达式
- ✅ 支持上下文行显示
- ✅ 支持 JSON 格式输出
- ✅ 支持文件统计信息

## 🤝 贡献

欢迎提交 Issue 和 PR！

**作者**: 黑米 (zhangxuzhao)  
**许可证**: MIT  
**仓库**: https://github.com/zhangxuzhao/openclaw-skills

---

🌾 **让黑米帮你快速找到需要的文件和内容！**
