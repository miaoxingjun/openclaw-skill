#!/usr/bin/env python3
"""
GrepTool - 文件内容搜索工具
类似 Claude Code 的 GrepTool，支持正则表达式、上下文行、多文件搜索

用法:
    python3 grep-tool.py <pattern> [options]

选项:
    --path PATH          搜索路径（默认: 当前目录）
    --glob GLOB          文件模式（默认: *，如 *.py, **/*.js）
    --context N          上下文行数（默认: 2）
    --case-sensitive     区分大小写（默认: 不区分）
    --max-results N      最大结果数（默认: 50）
    --json               输出 JSON 格式（默认: 文本格式）
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path
from glob import glob

def find_files(pattern, path, glob_pattern):
    """查找匹配的文件"""
    search_path = Path(path).expanduser()
    
    if not search_path.exists():
        print(f"❌ 路径不存在: {search_path}", file=sys.stderr)
        sys.exit(1)
    
    # 构建 glob 模式
    if glob_pattern:
        if '**' in glob_pattern:
            # 递归搜索
            file_pattern = str(search_path / glob_pattern)
        else:
            # 非递归搜索
            file_pattern = str(search_path / glob_pattern)
        files = glob(file_pattern, recursive=True)
    else:
        # 搜索所有文件
        files = [str(f) for f in search_path.rglob('*') if f.is_file()]
    
    return files

def grep_file(filepath, pattern, case_sensitive, context_lines):
    """在单个文件中搜索"""
    results = []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            regex = re.compile(pattern, flags)
        except re.error as e:
            return {'error': f'正则表达式错误: {e}', 'file': filepath}
        
        for i, line in enumerate(lines):
            if regex.search(line):
                # 获取上下文
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)
                context = lines[start:end]
                
                results.append({
                    'file': filepath,
                    'line': i + 1,  # 1-indexed
                    'content': line.rstrip(),
                    'context': {
                        'before': [l.rstrip() for l in context[:context_lines]],
                        'after': [l.rstrip() for l in context[context_lines+1:]]
                    }
                })
    except Exception as e:
        return {'error': str(e), 'file': filepath}
    
    return results

def main():
    parser = argparse.ArgumentParser(description='GrepTool - 文件内容搜索工具')
    parser.add_argument('pattern', help='搜索模式（支持正则表达式）')
    parser.add_argument('--path', default='.', help='搜索路径（默认: 当前目录）')
    parser.add_argument('--glob', default='*', help='文件模式（默认: *）')
    parser.add_argument('--context', type=int, default=2, help='上下文行数（默认: 2）')
    parser.add_argument('--case-sensitive', action='store_true', help='区分大小写')
    parser.add_argument('--max-results', type=int, default=50, help='最大结果数（默认: 50）')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    
    args = parser.parse_args()
    
    # 查找文件
    files = find_files(args.pattern, args.path, args.glob)
    
    if not files:
        if args.json:
            print(json.dumps([], ensure_ascii=False, indent=2))
        else:
            print("❌ 没有找到匹配的文件")
        sys.exit(0)
    
    # 搜索文件
    all_results = []
    for filepath in files:
        result = grep_file(filepath, args.pattern, args.case_sensitive, args.context)
        if isinstance(result, dict) and 'error' in result:
            print(f"⚠️  {result['error']}: {result['file']}", file=sys.stderr)
        elif isinstance(result, list):
            all_results.extend(result)
        
        # 限制结果数
        if len(all_results) >= args.max_results:
            break
    
    # 输出结果
    if args.json:
        print(json.dumps(all_results[:args.max_results], ensure_ascii=False, indent=2))
    else:
        if not all_results:
            print("❌ 没有找到匹配的内容")
            sys.exit(0)
        
        print(f"✅ 找到 {len(all_results)} 个匹配项:\n")
        for i, match in enumerate(all_results[:args.max_results], 1):
            rel_path = os.path.relpath(match['file'], args.path)
            print(f"{i}. 📄 {rel_path}:{match['line']}")
            print(f"   {match['content']}")
            if match['context']['before']:
                print(f"   ... ({len(match['context']['before'])} 行上文)")
            if match['context']['after']:
                print(f"   ... ({len(match['context']['after'])} 行下文)")
            print()

if __name__ == '__main__':
    main()
