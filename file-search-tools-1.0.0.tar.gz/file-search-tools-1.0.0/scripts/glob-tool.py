#!/usr/bin/env python3
"""
GlobTool - 文件路径模式匹配工具
类似 Claude Code 的 GlobTool，支持通配符搜索

用法:
    python3 glob-tool.py <pattern> [options]

选项:
    --path PATH          搜索路径（默认: 当前目录）
    --type TYPE          文件类型过滤（如: file, dir, all）
    --max-results N      最大结果数（默认: 100）
    --json               输出 JSON 格式（默认: 文本格式）
    --stats              显示统计信息
"""

import argparse
import json
import os
import sys
from pathlib import Path
from glob import glob
import fnmatch

def find_files(pattern, path, file_type='all'):
    """查找匹配的文件"""
    search_path = Path(path).expanduser()
    
    if not search_path.exists():
        print(f"❌ 路径不存在: {search_path}", file=sys.stderr)
        sys.exit(1)
    
    # 处理不同的模式
    if '**' in pattern:
        # 递归搜索
        file_pattern = str(search_path / pattern)
        files = glob(file_pattern, recursive=True)
    elif '*' in pattern or '?' in pattern:
        # 通配符搜索
        file_pattern = str(search_path / pattern)
        files = glob(file_pattern, recursive=False)
    else:
        # 精确匹配
        file_pattern = str(search_path / pattern)
        files = [file_pattern] if os.path.exists(file_pattern) else []
    
    # 过滤文件类型
    result = []
    for filepath in files:
        p = Path(filepath)
        if file_type == 'file' and not p.is_file():
            continue
        if file_type == 'dir' and not p.is_dir():
            continue
        result.append(filepath)
    
    return result

def format_size(size_bytes):
    """格式化文件大小"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"

def main():
    parser = argparse.ArgumentParser(description='GlobTool - 文件路径模式匹配工具')
    parser.add_argument('pattern', help='文件模式（支持通配符 *, **, ?）')
    parser.add_argument('--path', default='.', help='搜索路径（默认: 当前目录）')
    parser.add_argument('--type', choices=['file', 'dir', 'all'], default='file', help='文件类型（默认: file）')
    parser.add_argument('--max-results', type=int, default=100, help='最大结果数（默认: 100）')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--stats', action='store_true', help='显示统计信息')
    
    args = parser.parse_args()
    
    # 查找文件
    files = find_files(args.pattern, args.path, args.type)
    
    if not files:
        if args.json:
            print(json.dumps([], ensure_ascii=False, indent=2))
        else:
            print(f"❌ 没有找到匹配的文件: {args.pattern}")
        sys.exit(0)
    
    # 限制结果数
    files = files[:args.max_results]
    
    # 输出结果
    if args.json:
        result = []
        for filepath in files:
            p = Path(filepath)
            info = {
                'path': filepath,
                'relative_path': os.path.relpath(filepath, args.path),
                'type': 'file' if p.is_file() else 'dir',
            }
            if p.is_file():
                info['size'] = p.stat().st_size
                info['size_human'] = format_size(p.stat().st_size)
            result.append(info)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"✅ 找到 {len(files)} 个匹配项:\n")
        for i, filepath in enumerate(files, 1):
            rel_path = os.path.relpath(filepath, args.path)
            p = Path(filepath)
            
            if p.is_file():
                size = format_size(p.stat().st_size)
                print(f"{i}. 📄 {rel_path} ({size})")
            else:
                print(f"{i}. 📁 {rel_path}/")
        
        if args.stats:
            total_files = sum(1 for f in files if Path(f).is_file())
            total_dirs = sum(1 for f in files if Path(f).is_dir())
            total_size = sum(Path(f).stat().st_size for f in files if Path(f).is_file())
            
            print(f"\n📊 统计:")
            print(f"   文件: {total_files}")
            print(f"   目录: {total_dirs}")
            print(f"   总大小: {format_size(total_size)}")

if __name__ == '__main__':
    main()
