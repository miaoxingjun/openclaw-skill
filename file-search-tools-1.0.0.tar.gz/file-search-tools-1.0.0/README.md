# 🔍 File Search Tools Skill

> 智能文件搜索工具 - GrepTool + GlobTool

## 简介

File Search Tools 提供两个强大的文件搜索工具：

**GrepTool** - 文件内容搜索
- ✅ 支持正则表达式
- ✅ 显示上下文行
- ✅ JSON 格式输出

**GlobTool** - 文件路径匹配
- ✅ 支持通配符 `*`, `**`, `?`
- ✅ 文件统计信息
- ✅ 递归搜索

## 安装

```bash
openclaw skills install file-search-tools
```

## 快速开始

```bash
# GrepTool - 搜索内容
python3 ~/.openclaw/workspace/grep-tool.py "pattern" --glob "*.py"

# GlobTool - 查找文件
python3 ~/.openclaw/workspace/glob-tool.py "*.md" --stats
```

## 文档

详细文档请查看: [SKILL.md](SKILL.md)

## 文件结构

```
file-search-tools-1.0.0/
├── SKILL.md                 # Skill 主文档
├── README.md                # 本文件
├── scripts/
│   ├── grep-tool.py         # GrepTool 核心脚本
│   └── glob-tool.py         # GlobTool 核心脚本
└── docs/
    └── ADVANCED-USAGE.md    # 高级用法
```

## 许可证

MIT

## 作者

黑米 (zhangxuzhao)
